# SimpleMessageApp
A simple message app

# Steps to run the app

1. Open the terminal in the project and type the following Commands
   

      ```npm init```
   
      //skip the unneceesary by pressing the button 'enter'
   
     ``` npm install express bcryptjs body-parser cors jsonwebtoken socket.io socket.io-client sqlite3```
   
     ``` npm start```
   
   
3. Make sure you run the app in paste the below in browser
     http://localhost:3000/

4. Enjoy the messaging app created me (Akshith)
